package com.alibaba.fastjson.parser;

public abstract class AbstractJSONParser {

}
